// Public/GameFrameworkClassTable/AwakenCharacter.h
#pragma once
#include "AbilitySystemInterface.h"
#include "GameFramework/Character.h"
#include "AwakenCharacter.generated.h"

class UInputComponent;
class UHeldItemComponent;
class UCombatComponent;
class UCarryComponent;
class UCraftingComponent;
class UBuildToolComponent;
class UInteractionComponent;
class UDownedComponent;
class UShelterComponent;

UCLASS()
class THEAWAKEN_API AAwakenCharacter : public ACharacter, public IAbilitySystemInterface{
    GENERATED_BODY()
public:
    AAwakenCharacter(const FObjectInitializer& objectInitializer);

    virtual UAbilitySystemComponent* GetAbilitySystemComponent() const override;
    virtual void PossessedBy(AController* newController) override;
    virtual void OnRep_PlayerState() override;
    // Doc B18 guide Step 4 and 9: input binding on the local pawn, and the cleanup when control is lost.
    virtual void SetupPlayerInputComponent(UInputComponent* playerInputComponent) override;
    virtual void UnPossessed() override;

    UShelterComponent* getShelter() const{
        return shelter;
    }

private:
    void bindAbilitySystem();

    UPROPERTY(VisibleAnywhere)
    TObjectPtr<UHeldItemComponent> heldItem;

    UPROPERTY(VisibleAnywhere)
    TObjectPtr<UCombatComponent> combat;

    UPROPERTY(VisibleAnywhere)
    TObjectPtr<UCarryComponent> carry;

    UPROPERTY(VisibleAnywhere)
    TObjectPtr<UCraftingComponent> crafting;

    UPROPERTY(VisibleAnywhere)
    TObjectPtr<UBuildToolComponent> buildTool;

    UPROPERTY(VisibleAnywhere)
    TObjectPtr<UInteractionComponent> interaction;

    UPROPERTY(VisibleAnywhere)
    TObjectPtr<UDownedComponent> downed;

    UPROPERTY(VisibleAnywhere)
    TObjectPtr<UShelterComponent> shelter;
};
